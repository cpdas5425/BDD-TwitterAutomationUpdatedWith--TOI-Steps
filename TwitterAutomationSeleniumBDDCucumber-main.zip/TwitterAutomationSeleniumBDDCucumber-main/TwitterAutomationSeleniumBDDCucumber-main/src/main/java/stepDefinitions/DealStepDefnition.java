package stepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;


public class DealStepDefnition {
	//Thread.sleep(2000);  - All such static waits are kept for sake of video recording and execution flow to be visible 
	 WebDriver driver;
	 @Given("^user opens twitter Login Page$")
	 public void user_opens_twitter_login_page() throws Throwable{
	  System.setProperty("webdriver.chrome.driver","resources/chromedriver.exe");
		 
	 driver = new ChromeDriver();
	 driver.get("https://twitter.com/");
	 driver.manage().window().maximize();
		Thread.sleep(5000);
		 String title = driver.getTitle();
		 System.out.println(title);
		 	 Assert.assertEquals("Twitter. It’s what’s happening / Twitter", title);
		 	
		 
	 }
	 
	 @When("^user enters username and password and clicks on login button$")
	 public void user_enters_username_and_password(DataTable credentials){
		List<List<String>> data = credentials.raw();
	 driver.findElement(By.xpath("//input[@name='session[username_or_email]']")).sendKeys(data.get(1).get(2));
	 driver.findElement(By.xpath("//input[@name='session[password]']")).sendKeys(data.get(1).get(1));
	 WebElement loginBtn =
			 driver.findElement(By.xpath("//*[@id=\"react-root\"]/div/div/div/main/div/div/div/div[1]/div[1]/div/form/div/div[3]/div/div"));
			 JavascriptExecutor js = (JavascriptExecutor)driver;
			 js.executeScript("arguments[0].click();", loginBtn);
			 
	 }
	
	
	 @When("^Navigate profile page of logged user and upload a profile picture$")
	 public void user_clicks_on_login_button() throws Throwable {
	 //Click Profile
		 Thread.sleep(2000);
	 WebDriverWait wait = new WebDriverWait(driver,30);
	 WebElement Profile;
	 //Profile= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Profile')]"))); 
	 Profile= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[contains(text(),'Profile')]"))); 
	 
	 driver.findElement(By.xpath("//span[contains(text(),'Profile')]")).click();
	 
	 WebElement EditProfile;
	 EditProfile= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[contains(text(),'Edit profile')]"))); 
	 EditProfile.click();
	 Thread.sleep(2000);
	//Upload image
	 JavascriptExecutor jse = (JavascriptExecutor) driver; 
	 jse.executeScript("arguments[0].setAttribute('style', arguments[1])", driver.findElement(By.xpath("/descendant::input[@type='file'][1]")), "0");
	 jse.executeScript("arguments[0].setAttribute('class', arguments[1])", driver.findElement(By.xpath("/descendant::input[@type='file'][1]/../../div[2]")), "a");
	 driver.findElement(By.xpath("//input[@type='file']")).sendKeys("C:\\Users\\cd250049\\Desktop\\Test Twitter\\TwitterAutomationSeleniumBDDCucumber-main\\TwitterAutomationSeleniumBDDCucumber-main\\resources\\TwitterDP2.JPG");
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//span[contains(text(),'Apply')]")).click();
	 Thread.sleep(6000);
	 }
	
	 @When("^user Update BIO field in profile section as Selenium Automation user$")
	 public void user_enters_bio_on_profile_page() {
		 WebDriverWait wait = new WebDriverWait(driver,30);
	 //BIO
	 WebElement TextBio;
	 TextBio=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[4]/label[1]/div[1]/div[2]/div[1]/textarea[1]")));
	 TextBio.click();
	 TextBio.sendKeys(Keys.CONTROL+"A" + Keys.BACK_SPACE);
	 TextBio.sendKeys("Selenium Automation user");
	 }
	 
	 @When("^user Update Location field in profile section as Houston, Texas$")
	 public void user_enters_Location_on_profile_page() {
	 //Location
		 WebDriverWait wait = new WebDriverWait(driver,30);
	 WebElement Location;
	 Location=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[5]/label[1]/div[1]/div[2]/div[1]/input[1]")));
	 Location.click();
	 Location.sendKeys(Keys.CONTROL+"A" + Keys.BACK_SPACE);
	 Location.sendKeys("Houston, Texas");
	 }
	 
	 @When("^user Update Website field in profile section as twitter.com$")
	 public void user_enters_Website_on_profile_page() {
	//Website
		 WebDriverWait wait = new WebDriverWait(driver,30);
		 WebElement Website;
		 Website=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body/div[@id='react-root']/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[2]/div[1]/div[2]/div[1]/div[1]/div[6]/label[1]/div[1]/div[2]/div[1]/input[1]")));
		 Website.click();
		 Website.sendKeys(Keys.CONTROL+"A" + Keys.BACK_SPACE);
		 Website.sendKeys("https://twitter.com");
		 
		driver.findElement(By.xpath("//span[contains(text(),'Save')]")).click();
	 
	 }
	 @Then("^user Fetch BIO field ,location and website and check if the submit values got updated on the profile page$")
	 public void fetch_and_veify_user_details(DataTable userdata) throws InterruptedException {
		 List<List<String>> data = userdata.raw();
		 driver.navigate().refresh();
		 Thread.sleep(6000);
		 WebDriverWait wait = new WebDriverWait(driver,30);
		 WebElement UserBioelem;
		 UserBioelem=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[3]/div[1]/div[1]/span[1]")));
		// Fetch and Assert User details update is success
		 String UserBio = UserBioelem.getText();
		 System.out.println("UserBio ::"+ UserBio);
		 String UserLoc = driver.findElement(By.xpath("/html[1]/body[1]/div[1]/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[4]/div[1]/span[1]/span[1]/span[1]")).getText();
		 System.out.println("UserLoc ::"+ UserLoc);
		 String UserWebsite = driver.findElement(By.xpath("//body/div[@id='react-root']/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[4]/div[1]/a[1]")).getText();
		 System.out.println("UserWebsite ::"+ UserWebsite);
		 Assert.assertEquals(data.get(1).get(0), UserBio);
		 Assert.assertEquals(data.get(1).get(1), UserLoc);
		 Assert.assertEquals(data.get(1).get(2), UserWebsite);
	 }
	 
	 
	 @Then("^user Opens the twitter page of The Times of India and retrieve the tweets that were published in last 2 hrs$")
	 public void user_opens_TOI_Website() {
		 WebDriverWait wait = new WebDriverWait(driver,30);
	 
	 //TOI
	 WebElement SearchBox;
	 SearchBox=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//body/div[@id='react-root']/div[1]/div[1]/div[2]/main[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[2]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/div[1]/form[1]/div[1]/div[1]/div[1]/div[2]/input[1]")));
	 
	 SearchBox.sendKeys("The Times of India"+ Keys.ARROW_DOWN+Keys.ARROW_DOWN+Keys.ENTER);
	 /*********** 
	  *Get all the tweets 
	  * WebElements TOItweets = driver.findelements(By.Xath("Locator to fetch tweets"));
	  * Time currenttime = datetime.now()
	  * Time difftime = currenttime -120minutes; // to calculate time before 2 hours
	  *  for(int i=0, i<TOItweets.length(); i++){
	  *    if (TOItweets.get(i).getpagesource().getDateTimeStamp() >difftime){ ;
	  *    Save these tweets which were done in last 2 hours;
	  *    }
	  *  
	  *  }
	  * 
	  */
	 driver.get('https://twitter.com/TOI/followers')



	 followers_link=driver.page_source  #follwer page 18at a time
	 TimesOfIndia=TweetsTimesOfIndia(followers_link,'html.parser')

	 output=open('twitter_follower_r.csv','a')
	 output.write('Name,Twitter_Handle,Location,Bio,Join_Date,Link'+'\n')
	 div = TimesOfIndia.find('div',{'class':'GridTimeline-items has-items'})
	 bref = div.findAll('a',{'class':'ProfileCard-bg js-nav'})
	 name_list=[]
	 lastHeight = driver.execute_script("return document.body.scrollHeight")

	 followers_link=driver.page_source  #follwer page 18at a time
	 TimesOfIndia=TweetsTimesOfIndia(followers_link,'html.parser')

	 followers_per_page = 18
	 followers_count = 15777


	 for _ in xrange(0, followers_count/followers_per_page + 1):
	         driver.execute_script("window.scrollTo(0, 7755000);")
	         time.sleep(2)
	         newHeight = driver.execute_script("return document.body.scrollHeight")
	         if newHeight == lastHeight:
	                 followers_link=driver.page_source  #follwer page 18at a time
	                 TimesOfIndia=TweetsTimesOfIndia(followers_link,'html.parser')
	                 div = TimesOfIndia.find('div',{'class':'GridTimeline-items has-items'})
	                 bref = div.findAll('a',{'class':'ProfileCard-bg js-nav'})
	                 for name in bref:
	                         name_list.append(name['href'])
	                 break
	         lastHeight = newHeight
	         followers_link=''

	 print len(name_list)

	 '''
	 for x in range(0,len(name_list)):
	         #print name['href']
	         #print name.text
	         driver.stop_client()
	         driver.get('https://twitter.com'+name_list[x])
	         page_source=driver.page_source
	         each_TimesOfIndia=TweetsTimesOfIndia(page_source,'html.parser')
	         profile=each_TimesOfIndia.find('div',{'class':'ProfileHeaderCard'})
	                             
	         try:
	                 name = profile.find('h1',{'class':'ProfileHeaderCard-name'}).find('a').text
	                 if name:
	                         output.write('"'+name.strip().encode('utf-8')+'"'+',')
	                 else:
	                         output.write(' '+',')
	         except Exception as e:
	                 output.write(' '+',')
	                 print 'Error in name:',e

	         try:
	                 handle=profile.find('h2',{'class':'ProfileHeaderCard-screenname u-inlineBlock u-dir'}).text
	                 if handle:
	                         output.write('"'+handle.strip().encode('utf-8')+'"'+',')
	                 else:
	                         output.write(' '+',')
	         except Exception as e:
	                 output.write(' '+',')
	                 print 'Error in handle:',e

	         try:
	                 location = profile.find('div',{'class':'ProfileHeaderCard-location'}).text
	                 if location:
	                         output.write('"'+location.strip().encode('utf-8')+'"'+',')
	                 else:
	                         output.write(' '+',')
	         except Exception as e:
	                 output.write(' '+',')
	                 print 'Error in location:',e

	         try:
	                 bio=profile.find('p',{'class':'ProfileHeaderCard-bio u-dir'}).text
	                 if bio:
	                         output.write('"'+bio.strip().encode('utf-8')+'"'+',')
	                 else:
	                         output.write(' '+',')
	         except Exception as e:
	                 output.write(' '+',')
	                 print 'Error in bio:',e
	                         
	         try:
	                 joinDate = profile.find('div',{'class':'ProfileHeaderCard-joinDate'}).text
	                 if joinDate:
	                         output.write('"'+joinDate.strip().encode('utf-8')+'"'+',')
	                 else:
	                         output.write(' '+',')
	         except Exception as e:
	                 output.write(' '+',')
	                 print 'Error in joindate:',e
	         
	         try:
	                 url =  [check.find('a') for check in profile.find('div',{'class':'ProfileHeaderCard-url'}).findAll('span')][1]
	                 if url:
	                         output.write('"'+url['href'].strip().encode('utf-8')+'"'+'\n')
	                 else:
	                         output.write(' '+'\n')
	         except Exception as e:
	                 output.write(' '+'\n')
	                 print 'Error in url:',e
	         


	         
	 output.close()
	 
	 }
	 
	 @Then("^Close the browser$")
	 public void close_the_browser() throws Throwable{
		 Thread.sleep(6000);
		 driver.quit();
	 }
	
	
	
	

}

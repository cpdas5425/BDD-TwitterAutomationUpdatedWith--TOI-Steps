$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("src/main/java/Features/twitterTest.feature");
formatter.feature({
  "line": 1,
  "name": "QA automation solution for below requirements",
  "description": "",
  "id": "qa-automation-solution-for-below-requirements",
  "keyword": "Feature"
});
formatter.before({
  "duration": 115394,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "QA automation solution for Twitter Automation using BDD and Selenium",
  "description": "",
  "id": "qa-automation-solution-for-below-requirements;qa-automation-solution-for-twitter-automation-using-bdd-and-selenium",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 5,
  "name": "user opens twitter Login Page",
  "keyword": "Given "
});
formatter.step({
  "line": 6,
  "name": "user enters username and password and clicks on login button",
  "rows": [
    {
      "cells": [
        "username",
        "password",
        "accname"
      ],
      "line": 7
    },
    {
      "cells": [
        "cpdas5425@gmail.com",
        "Teradata@1234",
        "das_chandika"
      ],
      "line": 8
    },
    {
      "cells": [
        "UserBio",
        "UserLoc",
        "UserWebsite"
      ],
      "line": 9
    },
    {
      "cells": [
        "Selenium Automation user",
        "Houston, Texas",
        "twitter.com"
      ],
      "line": 10
    }
  ],
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "user Opens the twitter page of The Times of India and retrieve the tweets that were published in last 2 hrs",
  "keyword": "Then "
});
formatter.step({
  "line": 12,
  "name": "Close the browser",
  "keyword": "Then "
});
formatter.match({
  "location": "DealStepDefnition.user_opens_twitter_login_page()"
});
formatter.result({
  "duration": 5887631892,
  "error_message": "org.openqa.selenium.SessionNotCreatedException: session not created\nfrom chrome not reachable\n  (Session info: chrome\u003d86.0.4240.75)\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027WINCD250049-4TK\u0027, ip: \u0027192.168.1.206\u0027, os.name: \u0027Windows 10\u0027, os.arch: \u0027amd64\u0027, os.version: \u002710.0\u0027, java.version: \u002713.0.2\u0027\nDriver info: driver.version: ChromeDriver\nremote stacktrace: Backtrace:\n\tOrdinal0 [0x00F7C013+3194899]\n\tOrdinal0 [0x00E66021+2056225]\n\tOrdinal0 [0x00CFF4B0+586928]\n\tOrdinal0 [0x00CF5894+546964]\n\tOrdinal0 [0x00CF5F2C+548652]\n\tOrdinal0 [0x00CF7175+553333]\n\tOrdinal0 [0x00CF241E+533534]\n\tOrdinal0 [0x00D00620+591392]\n\tOrdinal0 [0x00CA2A0C+207372]\n\tOrdinal0 [0x00CA1D0D+204045]\n\tOrdinal0 [0x00C9FC1B+195611]\n\tOrdinal0 [0x00C83B7F+80767]\n\tOrdinal0 [0x00C84B4E+84814]\n\tOrdinal0 [0x00C84AD9+84697]\n\tOrdinal0 [0x00E7CE64+2149988]\n\tGetHandleVerifier [0x010EBE95+1400773]\n\tGetHandleVerifier [0x010EBB61+1399953]\n\tGetHandleVerifier [0x010F31FA+1430314]\n\tGetHandleVerifier [0x010EC69F+1402831]\n\tOrdinal0 [0x00E73D61+2112865]\n\tOrdinal0 [0x00E7E5CB+2155979]\n\tOrdinal0 [0x00E7E6F5+2156277]\n\tOrdinal0 [0x00E8F26E+2224750]\n\tBaseThreadInitThunk [0x76AF8674+36]\n\tRtlGetAppContainerNamedObjectPath [0x77665E17+311]\n\tRtlGetAppContainerNamedObjectPath [0x77665DE7+263]\n\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance0(Native Method)\r\n\tat java.base/jdk.internal.reflect.NativeConstructorAccessorImpl.newInstance(NativeConstructorAccessorImpl.java:62)\r\n\tat java.base/jdk.internal.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\r\n\tat java.base/java.lang.reflect.Constructor.newInstanceWithCaller(Constructor.java:500)\r\n\tat java.base/java.lang.reflect.Constructor.newInstance(Constructor.java:481)\r\n\tat org.openqa.selenium.remote.W3CHandshakeResponse.lambda$errorHandler$0(W3CHandshakeResponse.java:62)\r\n\tat org.openqa.selenium.remote.HandshakeResponse.lambda$getResponseFunction$0(HandshakeResponse.java:30)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.lambda$createSession$0(ProtocolHandshake.java:126)\r\n\tat java.base/java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:195)\r\n\tat java.base/java.util.Spliterators$ArraySpliterator.tryAdvance(Spliterators.java:958)\r\n\tat java.base/java.util.stream.ReferencePipeline.forEachWithCancel(ReferencePipeline.java:127)\r\n\tat java.base/java.util.stream.AbstractPipeline.copyIntoWithCancel(AbstractPipeline.java:502)\r\n\tat java.base/java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:488)\r\n\tat java.base/java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:474)\r\n\tat java.base/java.util.stream.FindOps$FindOp.evaluateSequential(FindOps.java:150)\r\n\tat java.base/java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)\r\n\tat java.base/java.util.stream.ReferencePipeline.findFirst(ReferencePipeline.java:543)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:128)\r\n\tat org.openqa.selenium.remote.ProtocolHandshake.createSession(ProtocolHandshake.java:74)\r\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:136)\r\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.startSession(RemoteWebDriver.java:213)\r\n\tat org.openqa.selenium.remote.RemoteWebDriver.\u003cinit\u003e(RemoteWebDriver.java:131)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:181)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:168)\r\n\tat org.openqa.selenium.chrome.ChromeDriver.\u003cinit\u003e(ChromeDriver.java:123)\r\n\tat stepDefinitions.DealStepDefnition.user_opens_twitter_login_page(DealStepDefnition.java:29)\r\n\tat ✽.Given user opens twitter Login Page(src/main/java/Features/twitterTest.feature:5)\r\n",
  "status": "failed"
});
formatter.match({
  "location": "DealStepDefnition.user_enters_username_and_password(DataTable)"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "DealStepDefnition.user_opens_TOI_Website()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "DealStepDefnition.close_the_browser()"
});
formatter.result({
  "status": "skipped"
});
formatter.after({
  "duration": 39273,
  "status": "passed"
});
});